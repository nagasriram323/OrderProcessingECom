﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Egen.PaymentSvc.Models.Request
{
    public class PaymentRequestModel
    {
        public List<PaymentRequest> Payments { get; set; }
    }

    public class PaymentRequest
    {
        public string PaymentType { get; set; }
        public int OrderId { get; set; }
        public decimal Amount { get; set; }
        public string CVV { get; set; }
        public string CardNumber { get; set; }
        public string BillingAddressLine1 { get; set; }
        public string BillingAddressLine2 { get; set; }
        public string BillingCity { get; set; }
        public string BillingState { get; set; }
        public string BillingZip { get; set; }
    }
}
