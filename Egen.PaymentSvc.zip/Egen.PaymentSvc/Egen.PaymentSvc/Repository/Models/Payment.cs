﻿using System.ComponentModel.DataAnnotations.Schema;

namespace Egen.PaymentSvc.Repository.Models
{
    public class Payment : Audit
    {
        public int PaymentId { get; set; }
        public string PaymentType { get; set; }
        public int OrderId { get; set; }
        public decimal Amount { get; set; }
        public string CVV { get; set; }
        public string CardNumber { get; set; }
        public string BillingAddressLine1 { get; set; }
        public string BillingAddressLine2 { get; set; }
        public string BillingCity { get; set; }
        public string BillingState { get; set; }
        public string BillingZip { get; set; }
    }
}
