﻿using Egen.PaymentSvc.PaymentRepository;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.Extensions.DependencyInjection;
using Egen.PaymentSvc.Models.Request;
using Egen.PaymentSvc.Repository.Models;
using Mapster;

namespace Egen.PaymentSvc.Services
{
    public class PaymentService : IPaymentService
    {
        private readonly IPaymentRepository _paymentRepository;
        private readonly ILogger<PaymentService> _logger;
        public PaymentService(IServiceProvider serviceProvider)
        {
            _paymentRepository = serviceProvider.GetService<IPaymentRepository>();
            _logger = serviceProvider.GetService<ILogger<PaymentService>>();
        }

        public async Task<bool> CreateOrderPaymentAsync(PaymentRequestModel paymentRequest)
        {
            bool response = false;
            try
            {
                List<Payment> payments = new List<Payment>();
                payments = paymentRequest.Payments.Adapt<List<Payment>>();
                payments.ForEach(x => x.CardNumber = Helper.Helper.Encrypt(x.CardNumber));
                payments.ForEach(x => x.CVV = Helper.Helper.Encrypt(x.CVV));
                response = await _paymentRepository.CreatePaymentAsync(payments).ConfigureAwait(false);
            }
            catch(Exception ex)
            {
                _logger.LogError(ex, "CreateOrderPaymentAsync");
                throw;
            }
            return response;
        }

        public async Task<bool> UpdateOrderPaymentAsync(PaymentRequestModel paymentRequest)
        {
            bool response = false;
            try
            {
                List<Payment> payments = new List<Payment>();
                payments = paymentRequest.Payments.Adapt<List<Payment>>();
                payments.ForEach(x => x.CardNumber = Helper.Helper.Encrypt(x.CardNumber));
                payments.ForEach(x => x.CVV = Helper.Helper.Encrypt(x.CVV));
                response = await _paymentRepository.UpdatePaymentAsync(payments).ConfigureAwait(false);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "UpdateOrderPaymentAsync");
                throw;
            }
            return response;
        }
    }
}
