﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Egen.PaymentSvc.Models.Request;
using Egen.PaymentSvc.Services;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;

namespace Egen.PaymentSvc.Controllers
{
    [ApiController]
    [Route("[controller]")]
    public class PaymentController : ControllerBase
    {

        private readonly ILogger<PaymentController> _logger;
        private readonly IPaymentService _paymentService;

        public PaymentController(ILogger<PaymentController> logger, IPaymentService paymentService)
        {
            _logger = logger;
            _paymentService = paymentService;
        }

        [HttpPost]
        [ProducesResponseType(200)]
        [AllowAnonymous]
        public async Task<IActionResult> CreatePayment([FromBody] PaymentRequestModel requestModel)
        {
            requestModel = requestModel ?? throw new ArgumentNullException(nameof(requestModel), $"The object {nameof(requestModel)} must be a non-empty.");
            var response = await _paymentService.CreateOrderPaymentAsync(requestModel).ConfigureAwait(false);
            return Ok(response);
        }

        [HttpPut("update")]
        [ProducesResponseType(200)]
        [AllowAnonymous]
        public async Task<IActionResult> UpdatePayment([FromBody] PaymentRequestModel requestModel)
        {
            requestModel = requestModel ?? throw new ArgumentNullException(nameof(requestModel), $"The object {nameof(requestModel)} must be a non-empty.");
            var response = await _paymentService.UpdateOrderPaymentAsync(requestModel).ConfigureAwait(false);
            return Ok(response);
        }
    }
}
