﻿-- Table: public.Payment

-- DROP TABLE public."Payment";

CREATE TABLE public.Payment
(
    PaymentId integer NOT NULL,
    PaymentType text ,
    "Amount" money NOT NULL,
    CVV text COLLATE pg_catalog."default" NOT NULL,
    CardNumber text COLLATE pg_catalog."default" NOT NULL,
    BillingAddressLine1 text COLLATE pg_catalog."default" NOT NULL,
    BillingAddressLine2 text COLLATE pg_catalog."default",
    BillingCity text COLLATE pg_catalog."default" NOT NULL,
    BillingState text COLLATE pg_catalog."default" NOT NULL,
    BillingZip text COLLATE pg_catalog."default" NOT NULL,
    "ShippingMethodId" integer NOT NULL,
    "Version" timestamp without time zone NOT NULL,
    "CreatedDate" date NOT NULL,
    "LastUpdatedDate" date,
    CONSTRAINT "Payment_pkey" PRIMARY KEY ("PaymentId"),
)

TABLESPACE pg_default;

ALTER TABLE public.Payment
    OWNER to postgres;