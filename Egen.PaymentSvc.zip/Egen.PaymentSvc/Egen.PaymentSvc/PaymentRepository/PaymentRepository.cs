﻿using EFCore.BulkExtensions;
using Egen.PaymentSvc.Repository;
using Egen.PaymentSvc.Repository.Models;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Egen.PaymentSvc.PaymentRepository
{
    public class PaymentRepository1 : IPaymentRepository
    {
        private readonly PaymentDbContext _dbContext;
        private readonly ILogger<PaymentRepository1> _logger;
        public PaymentRepository1(PaymentDbContext dbContext, ILogger<PaymentRepository1> logger)
        {
            _dbContext = (PaymentDbContext)dbContext;
            _logger = logger ?? throw new ArgumentNullException(nameof(logger));
        }

        public async Task<bool> CreatePaymentAsync(List<Payment> payments)
        {
            if (payments == null)
            {
                throw new ArgumentNullException(nameof(payments));
            }
            bool response = false;
            try
            {
                if (payments.Count == 1)
                {
                    await _dbContext.AddAsync(payments[0]).ConfigureAwait(false);
                    await _dbContext.SaveChangesAsync().ConfigureAwait(false);
                    return response = true;
                }
                else if (payments.Count > 1)
                {
                    await _dbContext.AddRangeAsync(payments).ConfigureAwait(false);
                    await _dbContext.SaveChangesAsync().ConfigureAwait(false);
                    return response = true;
                }
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, $"CreatePaymentAsync");
                throw;
            }
            return response;
        }

        public async Task<bool> UpdatePaymentAsync(List<Payment> payments)
        {
            if (payments == null)
            {
                throw new ArgumentNullException(nameof(payments));
            }
            bool response = false;
            try
            {
                await _dbContext.BulkUpdateAsync(payments).ConfigureAwait(false);
                await _dbContext.SaveChangesAsync().ConfigureAwait(false);
                response = true;
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, $"CreateBulkOrderAsync");
                throw;
            }
            return response;
        }
    }
}
