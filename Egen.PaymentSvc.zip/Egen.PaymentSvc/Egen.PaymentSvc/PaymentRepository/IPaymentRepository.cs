﻿using Egen.PaymentSvc.Repository.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Egen.PaymentSvc.PaymentRepository
{
    public interface IPaymentRepository
    {
        Task<bool> CreatePaymentAsync(List<Payment> payments);
        Task<bool> UpdatePaymentAsync(List<Payment> payments);
    }
}
