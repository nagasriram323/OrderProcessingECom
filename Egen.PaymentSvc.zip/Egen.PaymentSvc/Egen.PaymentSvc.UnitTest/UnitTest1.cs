using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace Egen.PaymentSvc.UnitTest
{
    [TestClass]
    public class UnitTest1
    {
        [TestMethod]
        public void TestMethod1()
        {
        }
    }
}
