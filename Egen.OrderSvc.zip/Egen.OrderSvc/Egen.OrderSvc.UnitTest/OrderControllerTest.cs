using Egen.OrderSvc.Controllers;
using Egen.OrderSvc.Models.RequestModel;
using Egen.OrderSvc.OrderRepository;
using Egen.OrderSvc.Repository;
using Egen.OrderSvc.Services;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Moq;
using Newtonsoft.Json;
using Newtonsoft.Json.Converters;
using Newtonsoft.Json.Serialization;
using System;
using System.IO;

namespace Egen.OrderSvc.UnitTest
{
    [TestClass]
    public class OrderControllerTest
    {
        private static OrderController _orderController;
        private static Mock<IServiceProvider> _serviceProvider;
        private static Mock<ILogger<OrderService>> _logger;
        private readonly Mock<IOrderRepository> _orderRepo;
        private readonly Mock<IOrderService> _orderService;

        public OrderControllerTest()
        {
            JsonConvert.DefaultSettings = () =>
            {
                var settings = new JsonSerializerSettings
                {
                    NullValueHandling = NullValueHandling.Ignore,
                    ContractResolver = new CamelCasePropertyNamesContractResolver()
                };
                settings.Converters.Add(new StringEnumConverter(new CamelCaseNamingStrategy(), true));
                settings.Formatting = Formatting.Indented;

                return settings;
            };

            _serviceProvider = new Mock<IServiceProvider>();
            _logger = new Mock<ILogger<OrderService>>();
            _orderRepo = new Mock<IOrderRepository>();
            _orderService = new Mock<IOrderService>();

            _serviceProvider.Setup(x => x.GetService(typeof(IServiceProvider))).Returns(_serviceProvider.Object);
            _serviceProvider.Setup(x => x.GetService(typeof(ILogger<OrderService>))).Returns(_logger.Object);
            _serviceProvider.Setup(x => x.GetService(typeof(IOrderRepository))).Returns(_orderRepo.Object);
            _serviceProvider.Setup(x => x.GetService(typeof(OrderDbContext))).Returns(_serviceProvider.Object);
            _serviceProvider.Setup(x => x.GetService(typeof(IOrderService))).Returns(new OrderService(_serviceProvider.Object));
            _orderController = new OrderController(_serviceProvider.Object);
        }

        [TestMethod]
        public async void Create_Order_TestMethod()
        {
            var testOrder = await File.ReadAllTextAsync(Directory.GetCurrentDirectory() + "./Mock_Add_Order.json").ConfigureAwait(false);
            var testOrderDeserialized = JsonConvert.DeserializeObject<OrderRequestModel>(testOrder);
            var result = await _orderController.CreateOrder(testOrderDeserialized).ConfigureAwait(false);
            var result1 = result as OkObjectResult;
            Assert.Equals(200, result1.StatusCode);
            Assert.IsTrue(true);
        }

        [TestMethod]
        public async void Create_Bulk_TestMethod()
        {
            var testOrder = await File.ReadAllTextAsync(Directory.GetCurrentDirectory() + "./Mock_Bulk_Order.json").ConfigureAwait(false);
            var testOrderDeserialized = JsonConvert.DeserializeObject<BulkOrderRequestModel>(testOrder);
            var result = await _orderController.CreateBulkFileOrders(testOrderDeserialized).ConfigureAwait(false);
            var result1 = result as OkObjectResult;
            Assert.Equals(200, result1.StatusCode);
            Assert.IsTrue(true);
        }
    }
}
