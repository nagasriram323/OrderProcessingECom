﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Egen.OrderSvc.Models.RequestModel;
using Egen.OrderSvc.Models.ResponseModel;
using Egen.OrderSvc.Services;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.DependencyInjection;

namespace Egen.OrderSvc.Controllers
{
    [ApiController]
    [Route("api/v1/[controller]")]
    public class OrderController : ControllerBase
    {
        private readonly ILogger<OrderController> _logger;
        private readonly IOrderService _orderService;

        public OrderController(IServiceProvider serviceProvider)
        {
            _logger = serviceProvider.GetService<ILogger<OrderController>>();
            _orderService = serviceProvider.GetService<IOrderService>();
        }

        [HttpPost]
        [ProducesResponseType(200)]
        [AllowAnonymous]
        public async Task<IActionResult> CreateOrder([FromBody] OrderRequestModel requestModel)
        {
            requestModel = requestModel ?? throw new ArgumentNullException(nameof(requestModel), $"The object {nameof(requestModel)} must be a non-empty.");
            await _orderService.CreateOrderAsync(requestModel).ConfigureAwait(false);
            return Ok();
        }

        [HttpGet("GetOrderDetails/{orderId}")]
        [ProducesResponseType(typeof(OrderDetailsResponseModel), 200)]
        [AllowAnonymous]
        public async Task<IActionResult> GetOrderDetails(int orderId)
        {
            if (orderId <= 0) throw new ArgumentOutOfRangeException(nameof(orderId), $"Invalid input {nameof(orderId)}.");

            var result = await _orderService.GetOrderDetailsAsync(orderId).ConfigureAwait(false);
            if (result == null) throw new ArgumentNullException(nameof(orderId), "Specified order doesn't exist in the system!");

            return Ok(result);
        }

        [HttpPut]
        [ProducesResponseType(200)]
        [AllowAnonymous]
        public async Task<IActionResult> CancelOrder(int orderId)
        {
            if (orderId <= 0) throw new ArgumentOutOfRangeException(nameof(orderId), $"Invalid input {nameof(orderId)}.");
            await _orderService.CancelOrderAsync(orderId).ConfigureAwait(false);
            return Ok();
        }

        [HttpPost("bulkfileorders")]
        [ProducesResponseType(200)]
        [AllowAnonymous]
        // This is built with an assumption that bulk orders are placed by a customer.
        // Example: 10 orders placed by one customer.
        public async Task<IActionResult> CreateBulkFileOrders([FromBody] BulkOrderRequestModel requestModel)
        {
            requestModel = requestModel ?? throw new ArgumentNullException(nameof(requestModel), $"The object {nameof(requestModel)} must be a non-empty.");
            await _orderService.CreateBulkOrdersAsync(requestModel).ConfigureAwait(false);
            return Ok();
        }

        [HttpPut("bulkfileorders")]
        [ProducesResponseType(200)]
        [AllowAnonymous]
        public async Task<IActionResult> UpdateBulkFileOrders([FromBody] BulkOrderRequestModel requestModel)
        {
            requestModel = requestModel ?? throw new ArgumentNullException(nameof(requestModel), $"The object {nameof(requestModel)} must be a non-empty.");
            await _orderService.UpdateBulkOrdersAsync(requestModel).ConfigureAwait(false);
            return Ok();
        }
    }
}
