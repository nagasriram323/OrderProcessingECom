﻿-- Table: public.OrderStatus

-- DROP TABLE public."OrderStatus";

CREATE TABLE public."OrderStatus"
(
    "OrderStatusId" integer NOT NULL,
    "OrderStatusName" text COLLATE pg_catalog."default" NOT NULL,
    "OrderStatusDescription" text COLLATE pg_catalog."default",
    "CreatedDate" date NOT NULL,
    "LastUpdatedDate" date,
    "Version" timestamp without time zone,
    CONSTRAINT "OrderStatus_pkey" PRIMARY KEY ("OrderStatusId")
)

TABLESPACE pg_default;

ALTER TABLE public."OrderStatus"
    OWNER to postgres;