﻿-- Table: public.OrderCustomer

-- DROP TABLE public."OrderCustomer";

CREATE TABLE public."OrderCustomer"
(
    "OrderCustomerId" integer NOT NULL,
    "OrderId" integer NOT NULL,
    "CustomerId" integer NOT NULL,
    "CreatedDate" date NOT NULL,
    "LastUpdatedDate" date,
    "Version" time without time zone NOT NULL,
    CONSTRAINT "OrderCustomer_pkey" PRIMARY KEY ("OrderCustomerId"),
    CONSTRAINT "OrderCustomer_CustomerId_fkey" FOREIGN KEY ("CustomerId")
        REFERENCES public."Customer" ("CustomerId") MATCH SIMPLE
        ON UPDATE NO ACTION
        ON DELETE NO ACTION,
    CONSTRAINT "OrderCustomer_OrderId_fkey" FOREIGN KEY ("OrderId")
        REFERENCES public."Order" ("OrderId") MATCH SIMPLE
        ON UPDATE NO ACTION
        ON DELETE NO ACTION
)

TABLESPACE pg_default;

ALTER TABLE public."OrderCustomer"
    OWNER to postgres;