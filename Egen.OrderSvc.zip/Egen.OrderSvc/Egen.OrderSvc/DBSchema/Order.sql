﻿-- Table: public.Order

-- DROP TABLE public."Order";

CREATE TABLE public."Order"
(
    "OrderId" integer NOT NULL,
    "OrderStatusId" integer NOT NULL,
    "CreatedDate" date NOT NULL,
    "LastUpdatedDate" date,
    "Version" time without time zone NOT NULL,
    "OrderConfirmationNumber" text COLLATE pg_catalog."default" NOT NULL,
    "TotalBulkOrders" integer,
    CONSTRAINT "Order_pkey" PRIMARY KEY ("OrderId")
)

TABLESPACE pg_default;

ALTER TABLE public."Order"
    OWNER to postgres;