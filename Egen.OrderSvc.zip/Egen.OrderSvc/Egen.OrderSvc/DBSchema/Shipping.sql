﻿-- Table: public.Shipping

-- DROP TABLE public."Shipping";

CREATE TABLE public."Shipping"
(
    "ShippingId" integer NOT NULL,
    "CustomerId" integer NOT NULL,
    "OrderId" integer NOT NULL,
    "AddressLine1" text COLLATE pg_catalog."default",
    "AddressLine2" text COLLATE pg_catalog."default",
    "City" text COLLATE pg_catalog."default",
    "State" text COLLATE pg_catalog."default",
    "Zip" text COLLATE pg_catalog."default",
    "ShippingMethodId" integer NOT NULL,
    "CreatedDate" date NOT NULL,
    "LastUpdatedDate" date,
    "Version" timestamp without time zone NOT NULL,
    CONSTRAINT "OrderCustomer_OrderId_fkey" FOREIGN KEY ("OrderId")
        REFERENCES public."Order" ("OrderId") MATCH SIMPLE
        ON UPDATE NO ACTION
        ON DELETE NO ACTION
    CONSTRAINT "Shipping_pkey" PRIMARY KEY ("ShippingId"),
    CONSTRAINT "CustomerId" FOREIGN KEY ("CustomerId")
        REFERENCES public."Customer" ("CustomerId") MATCH SIMPLE
        ON UPDATE NO ACTION
        ON DELETE NO ACTION,
    CONSTRAINT "ShippingMethodId" FOREIGN KEY ("ShippingMethodId")
        REFERENCES public."ShippingMethod" ("ShippingMethodId") MATCH SIMPLE
        ON UPDATE NO ACTION
        ON DELETE NO ACTION
        NOT VALID
)

TABLESPACE pg_default;

ALTER TABLE public."Shipping"
    OWNER to postgres;