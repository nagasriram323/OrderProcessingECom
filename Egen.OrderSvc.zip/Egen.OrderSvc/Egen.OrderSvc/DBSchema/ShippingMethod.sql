﻿-- Table: public.ShippingMethod

-- DROP TABLE public."ShippingMethod";

CREATE TABLE public."ShippingMethod"
(
    "ShippingMethodId" integer NOT NULL,
    "ShippingMethodName" text COLLATE pg_catalog."default" NOT NULL,
    "ShippingMethodDescription" text COLLATE pg_catalog."default",
    "CreatedDate" date NOT NULL,
    "LastUpdatedDate" date,
    "Version" timestamp without time zone NOT NULL,
    CONSTRAINT "ShippingMethod_pkey" PRIMARY KEY ("ShippingMethodId")
)

TABLESPACE pg_default;

ALTER TABLE public."ShippingMethod"
    OWNER to postgres;