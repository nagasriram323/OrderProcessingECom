﻿-- Table: public.Item

-- DROP TABLE public."Item";

CREATE TABLE public."Item"
(
    "ItemId" integer NOT NULL,
    "ItemName" text COLLATE pg_catalog."default" NOT NULL,
    "ItemDescription" text COLLATE pg_catalog."default",
    "CreatedDate" date NOT NULL,
    "LastUpdatedDate" date,
    "Version" timestamp without time zone NOT NULL,
    CONSTRAINT "Item_pkey" PRIMARY KEY ("ItemId")
)

TABLESPACE pg_default;

ALTER TABLE public."Item"
    OWNER to postgres;