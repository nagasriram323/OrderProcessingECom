﻿-- Table: public.BulkOrder

-- DROP TABLE public."BulkOrder";

CREATE TABLE public."BulkOrder"
(
    "BulkOrderId" integer NOT NULL,
    "OrderId" integer NOT NULL,
    "FirstName" text COLLATE pg_catalog."default" NOT NULL,
    "LastName" text COLLATE pg_catalog."default" NOT NULL,
    "Phone" text COLLATE pg_catalog."default" NOT NULL,
    "Email" text COLLATE pg_catalog."default" NOT NULL,
    "ItemName" text COLLATE pg_catalog."default" NOT NULL,
    "ItemDescription" text COLLATE pg_catalog."default",
    "AddressLine1" text COLLATE pg_catalog."default" NOT NULL,
    "AddressLine2" text COLLATE pg_catalog."default",
    "City" text COLLATE pg_catalog."default" NOT NULL,
    "State" text COLLATE pg_catalog."default" NOT NULL,
    "Zip" text COLLATE pg_catalog."default" NOT NULL,
    "ShippingMethodId" integer NOT NULL,
    "Version" timestamp without time zone NOT NULL,
    "CreatedDate" date NOT NULL,
    "LastUpdatedDate" date,
    CONSTRAINT "BulkOrder_pkey" PRIMARY KEY ("BulkOrderId"),
    CONSTRAINT "BulkOrder_OrderId_fkey" FOREIGN KEY ("OrderId")
        REFERENCES public."Order" ("OrderId") MATCH SIMPLE
        ON UPDATE NO ACTION
        ON DELETE NO ACTION,
    CONSTRAINT "BulkOrder_ShippingMethodId_fkey" FOREIGN KEY ("ShippingMethodId")
        REFERENCES public."ShippingMethod" ("ShippingMethodId") MATCH SIMPLE
        ON UPDATE NO ACTION
        ON DELETE NO ACTION
)

TABLESPACE pg_default;

ALTER TABLE public."BulkOrder"
    OWNER to postgres;