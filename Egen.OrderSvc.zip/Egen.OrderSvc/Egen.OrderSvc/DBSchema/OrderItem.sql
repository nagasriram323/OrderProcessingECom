﻿-- Table: public.OrderItem

-- DROP TABLE public."OrderItem";

CREATE TABLE public."OrderItem"
(
    "OrderItemId" integer NOT NULL,
    "ItemId" integer NOT NULL,
    "ItemQuantity" integer NOT NULL,
    "ItemPrice" money NOT NULL,
    
    "Total" money NOT NULL,
    "Version" timestamp without time zone NOT NULL,
    "CreatedDate" date NOT NULL,
    "LastUpdatedDate" date,
    CONSTRAINT "OrderItem_pkey" PRIMARY KEY ("OrderItemId"),
    CONSTRAINT "OrderItem_ItemId_fkey" FOREIGN KEY ("ItemId")
        REFERENCES public."Item" ("ItemId") MATCH SIMPLE
        ON UPDATE NO ACTION
        ON DELETE NO ACTION
)

TABLESPACE pg_default;

ALTER TABLE public."OrderItem"
    OWNER to postgres;