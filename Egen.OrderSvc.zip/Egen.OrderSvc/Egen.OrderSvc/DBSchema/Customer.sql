﻿-- Table: public.Customer

-- DROP TABLE public."Customer";

CREATE TABLE public."Customer"
(
    "CustomerId" integer NOT NULL,
    "FirstName" text COLLATE pg_catalog."default" NOT NULL,
    "LastName" text COLLATE pg_catalog."default" NOT NULL,
    "Phone" text COLLATE pg_catalog."default",
    "Email" text COLLATE pg_catalog."default",
    "Version" timestamp without time zone NOT NULL,
    "CreatedDate" date NOT NULL,
    "LastUpdatedDate" date,
    CONSTRAINT "Customer_pkey" PRIMARY KEY ("CustomerId")
)

TABLESPACE pg_default;

ALTER TABLE public."Customer"
    OWNER to postgres;