﻿using Egen.OrderSvc.Models.RequestModel;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Egen.OrderSvc.ExternalServices.PaymentSvc
{
    public interface IPaymentSvcProxy
    {
        Task<bool> CreateOrderPaymentAsync(PaymentRequestModel requestModel);

        Task<bool> UpdateOrderPaymentAsync(PaymentRequestModel requestModel);
    }
}
