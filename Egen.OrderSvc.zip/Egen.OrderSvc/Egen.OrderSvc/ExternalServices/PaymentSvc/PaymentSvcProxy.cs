﻿using Egen.OrderSvc.ExternalServices.Config;
using Egen.OrderSvc.Models.RequestModel;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;

namespace Egen.OrderSvc.ExternalServices.PaymentSvc
{
    public class PaymentSvcProxy : IPaymentSvcProxy
    {

        private const string _svcName = "PaymentSvc";

        private readonly ExternalServiceConfig _config;
        private readonly IHttpClientFactory _httpClientFactory;
        private readonly ILogger<PaymentSvcProxy> _logger;

        public PaymentSvcProxy(ILogger<PaymentSvcProxy> logger, IOptions<ExternalServiceConfig> externalServiceConfig, IHttpClientFactory httpClientFactory)
        {
            _config = (ExternalServiceConfig)externalServiceConfig;
            _httpClientFactory = httpClientFactory;
            _logger = logger ?? throw new ArgumentNullException(nameof(logger));
        }
        protected HttpClient HttpClient => _httpClientFactory.CreateClient("Context");

        public async Task<bool> CreateOrderPaymentAsync(PaymentRequestModel requestModel)
        {
            if (requestModel == null)
            {
                throw new ArgumentNullException(nameof(requestModel));
            }

            bool paymentResponse = false;

            string endpoint = _config.Args["CreatePayment"];
            var serviceUri = new Uri($"{_config.Host}/{endpoint}");
            using StringContent payload = new StringContent(JsonConvert.SerializeObject(requestModel), Encoding.UTF8, "application/json");
            using HttpResponseMessage response = await HttpClient.PostAsync(serviceUri, payload).ConfigureAwait(false);
            try
            {
                response.EnsureSuccessStatusCode();
                var responseString = await response.Content.ReadAsStringAsync().ConfigureAwait(false);
                if (!string.IsNullOrEmpty(responseString))
                    paymentResponse = true;
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "PostDataAsync to {requestUri} failed at {responseCode}", serviceUri.AbsolutePath, response.StatusCode);
                throw;
            }
            return paymentResponse;
        }

        public async Task<bool> UpdateOrderPaymentAsync(PaymentRequestModel requestModel)
        {
            if (requestModel == null)
            {
                throw new ArgumentNullException(nameof(requestModel));
            }

            bool paymentResponse = false;

            string endpoint = _config.Args["UpdatePayment"];
            var serviceUri = new Uri($"{_config.Host}/{endpoint}");
            using StringContent payload = new StringContent(JsonConvert.SerializeObject(requestModel), Encoding.UTF8, "application/json");
            using HttpResponseMessage response = await HttpClient.PutAsync(serviceUri, payload).ConfigureAwait(false);
            try
            {
                response.EnsureSuccessStatusCode();
                var responseString = await response.Content.ReadAsStringAsync().ConfigureAwait(false);
                if (!string.IsNullOrEmpty(responseString))
                    paymentResponse = true;
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "PostDataAsync to {requestUri} failed at {responseCode}", serviceUri.AbsolutePath, response.StatusCode);
                throw;
            }
            return paymentResponse;
        }
    }
}
