﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Egen.OrderSvc.ExternalServices.Config
{
    public class ExternalServiceConfig
    {
        public string Host { get; set; }
        public string ExternalHost { get; set; }
        public Dictionary<string, string> Args { get; set; }
    }
}
