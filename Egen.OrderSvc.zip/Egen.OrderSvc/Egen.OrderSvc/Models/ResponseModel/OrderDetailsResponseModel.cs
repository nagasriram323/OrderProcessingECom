﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Egen.OrderSvc.Models.ResponseModel
{
    public class OrderDetailsResponseModel
    {
        public string ItemName { get; set; }
        public string ItemDescription { get; set; }
        public string CustomerName { get; set; }
        public int ItemQuantity { get; set; }
        public string AddressLine1 { get; set; }
        public string AddressLine2 { get; set; }
        public string City { get; set; }
        public string State { get; set; }
        public decimal Total { get; set; }
    }
}
