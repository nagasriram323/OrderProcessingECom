﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Egen.OrderSvc.Models.ResponseModel
{
    public class DataModel
    {
        public int TypeId { get; set; }
        public string TypeCode { get; set; }
        public string TypeDescription { get; set; }

    }
}
