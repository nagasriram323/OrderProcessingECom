﻿using Egen.OrderSvc.Repository.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Egen.OrderSvc.Models.RequestModel
{
    public class OrderRequestModel
    {
        public int ItemId { get; set; }
        public int ItemQuantity { get; set; }
        public decimal ItemPrice { get; set; }
        public int CustomerId { get; set; }
        public string OrderStatusName { get; set; }
        public ShippingModel Shipping { get; set; }
        public List<Payment> Payments { get; set; }
    }
}
