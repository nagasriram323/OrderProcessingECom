﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Egen.OrderSvc.Models.RequestModel
{
    public class BulkOrderRequestModel
    {
        public List<BulkRequest> BulkRequests { get; set; }
        public int? OrderId { get; set; }
    }
}
