﻿using System.Collections.Generic;

namespace Egen.OrderSvc.Models.RequestModel
{
    public class PaymentRequestModel
    {
        public List<Payment> Payments { get; set; }
    }

    public class Payment
    {
        public string PaymentType { get; set; }
        public int OrderId { get; set; }
        public decimal Amount { get; set; }
        public string CVV { get; set; }
        public string CardNumber { get; set; }
        public string BillingAddressLine1 { get; set; }
        public string BillingAddressLine2 { get; set; }
        public string BillingCity { get; set; }
        public string BillingState { get; set; }
        public string BillingZip { get; set; }
    }
}