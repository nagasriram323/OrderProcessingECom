﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Egen.OrderSvc.Models.RequestModel
{
    public class BulkRequest
    {
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public string Phone { get; set; }
        public string Email { get; set; }
        public string ItemName { get; set; }
        public string ItemDescription { get; set; }
        public string AddressLine1 { get; set; }
        public string AddressLine2 { get; set; }
        public string City { get; set; }
        public string State { get; set; }
        public string Zip { get; set; }
        public string ShippingMethodName { get; set; }
        public string PaymentType { get; set; }
        public int OrderId { get; set; }
        public decimal Amount { get; set; }
        public string CVV { get; set; }
        public string CardNumber { get; set; }
        public string BillingAddressLine1 { get; set; }
        public string BillingAddressLine2 { get; set; }
        public string BillingCity { get; set; }
        public string BillingState { get; set; }
        public string BillingZip { get; set; }

    }
}
