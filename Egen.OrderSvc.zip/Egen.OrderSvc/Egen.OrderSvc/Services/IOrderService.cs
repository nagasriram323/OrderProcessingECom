﻿using Egen.OrderSvc.Models.RequestModel;
using Egen.OrderSvc.Models.ResponseModel;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Egen.OrderSvc.Services
{
    public interface IOrderService
    {
        Task CreateOrderAsync(OrderRequestModel requestModel);
        Task<OrderDetailsResponseModel> GetOrderDetailsAsync(int orderId);
        Task CancelOrderAsync(int orderId);
        Task CreateBulkOrdersAsync(BulkOrderRequestModel requestModel);
        Task UpdateBulkOrdersAsync(BulkOrderRequestModel requestModel);
    }
}
