﻿using Egen.OrderSvc.OrderRepository;
using Microsoft.Extensions.Logging;
using System;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.Extensions.DependencyInjection;
using Egen.OrderSvc.Models.RequestModel;
using Egen.OrderSvc.Repository.Models;
using Egen.OrderSvc.ExternalServices.PaymentSvc;
using System.Collections.Generic;
using Mapster;
using Egen.OrderSvc.Models.ResponseModel;

namespace Egen.OrderSvc.Services
{
    public class OrderService : IOrderService
    {
        private readonly IOrderRepository _orderRepository;
        private readonly ILogger<OrderService> _logger;
        private readonly IPaymentSvcProxy _paymentSvcProxy;
        private const string ShipByMail = "ShipByMail";
        private const int TaxPercentage = 3;
        public OrderService(IServiceProvider serviceProvider)
        {
            _orderRepository = serviceProvider.GetService<IOrderRepository>();
            _logger = serviceProvider.GetService<ILogger<OrderService>>();
            _paymentSvcProxy = serviceProvider.GetService<IPaymentSvcProxy>();
        }

        public async Task CreateOrderAsync(OrderRequestModel requestModel)
        {
            try
            {
                var shippingMethods = await _orderRepository.GetShippingMethodDataAync().ConfigureAwait(false);
                var orderId = await ProcessOrderAsync(null).ConfigureAwait(false);
                bool paymentResponse = await ProcessPaymentAsync(requestModel.Payments, orderId);
                if (paymentResponse)
                {
                    await _orderRepository.CreateOrderCustomerAsync(new OrderCustomer
                    {
                        CreatedDate = DateTimeOffset.UtcNow.Date,
                        CustomerId = requestModel.CustomerId,
                        OrderId = orderId.Value
                    }).ConfigureAwait(false);

                    OrderItem orderItem = new OrderItem();
                    orderItem.CreatedDate = DateTimeOffset.UtcNow.Date;
                    orderItem.ItemId = requestModel.ItemId;
                    orderItem.ItemPrice = requestModel.ItemPrice;
                    orderItem.ItemQuantity = requestModel.ItemQuantity;
                    orderItem.Tax = (TaxPercentage / requestModel.ItemPrice) * 100;
                    orderItem.Total = (requestModel.ItemPrice + orderItem.Tax) * requestModel.ItemQuantity;
                    await _orderRepository.CreateOrderItemAsync(orderItem).ConfigureAwait(false);

                    var shipMethod = shippingMethods.Where(s => s.TypeCode == requestModel.Shipping.ShippingMethodName).FirstOrDefault();
                    if (shipMethod != null)
                    {
                        Shipping shipping = new Shipping();
                        shipping.OrderId = orderId.Value;
                        shipping.CreatedDate = DateTimeOffset.UtcNow.Date;
                        shipping.ShippingMethodId = shipMethod.TypeId;
                        shipping.CustomerId = requestModel.CustomerId;
                        if (shipMethod.TypeCode == ShipByMail)
                        {
                            shipping.AddressLine1 = requestModel.Shipping.AddressLine1;
                            shipping.AddressLine2 = requestModel.Shipping.AddressLine2;
                            shipping.City = requestModel.Shipping.City;
                            shipping.State = requestModel.Shipping.State;
                            shipping.Zip = requestModel.Shipping.Zip;
                        }
                        await _orderRepository.CreateShippingAsync(shipping).ConfigureAwait(false);
                    }
                }
                else
                {
                    _logger.LogError("Order creation failed.");
                }
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "CreateOrderAsync");
                throw;
            }
        }

        public async Task<Models.ResponseModel.OrderDetailsResponseModel> GetOrderDetailsAsync(int orderId)
        {
            if (orderId <= 0) throw new ArgumentOutOfRangeException($"{nameof(orderId)} should be positive integer.");
            var results = await _orderRepository.GetOrderDetailsAsync(orderId).ConfigureAwait(false);
            return results;
        }

        public async Task CancelOrderAsync(int orderId)
        {
            if (orderId <= 0) throw new ArgumentOutOfRangeException($"{nameof(orderId)} should be positive integer.");
            await _orderRepository.CancelOrderAsync(orderId).ConfigureAwait(false);
        }

        public async Task CreateBulkOrdersAsync(BulkOrderRequestModel requestModel)
        {
            try
            {
                var orderId = await ProcessOrderAsync(requestModel?.BulkRequests.Count).ConfigureAwait(false);
                var shippingMethods = await _orderRepository.GetShippingMethodDataAync().ConfigureAwait(false);
                if (orderId.HasValue && orderId.Value > 0)
                {
                    var bulkPayments = requestModel.BulkRequests.GroupBy(grp => grp.CardNumber).Select(card => card.First()).ToList();
                    List<Payment> payments = new List<Payment>();
                    foreach (var bulkPayment in bulkPayments)
                    {
                        var payment = bulkPayment.Adapt<Payment>();
                        payments.Add(payment);
                    }
                    bool processPaymentSuccess = await ProcessPaymentAsync(payments, orderId).ConfigureAwait(false);
                    if (processPaymentSuccess)
                    {
                        List<BulkOrder> bulkOrders = new List<BulkOrder>();
                        foreach (var bulkOrderRequest in requestModel.BulkRequests)
                        {
                            var bulkOrder = new BulkOrder();
                            bulkOrder = bulkOrderRequest.Adapt<BulkOrder>();
                            bulkOrder.ShippingMethodId = shippingMethods.Where(s => s.TypeCode == bulkOrderRequest.ShippingMethodName).FirstOrDefault().TypeId;
                            bulkOrder.CreatedDate = DateTimeOffset.UtcNow.Date;
                            bulkOrders.Add(bulkOrder);
                        }
                        var bulkOrdersSuccess = await _orderRepository.CreateBulkOrderAsync(bulkOrders).ConfigureAwait(false);
                    }
                }
            }
            catch(Exception ex)
            {
                _logger.LogError(ex, "CreateBulkOrdersAsync");
                throw;
            }
        }

        public async Task UpdateBulkOrdersAsync(BulkOrderRequestModel requestModel)
        {
            try
            {
                if (requestModel.OrderId.HasValue && requestModel.OrderId.Value > 0)
                {
                    var bulkOrders = await _orderRepository.GetBulkOrdersAsync(requestModel.OrderId.Value).ConfigureAwait(false);
                    var shippingMethods = await _orderRepository.GetShippingMethodDataAync().ConfigureAwait(false);
                    if (bulkOrders?.Count > 0)
                    {
                        var bulkPayments = requestModel.BulkRequests.GroupBy(grp => grp.CardNumber).Select(card => card.First()).ToList();
                        List<Payment> payments = new List<Payment>();
                        foreach (var bulkPayment in bulkPayments)
                        {
                            var payment = bulkPayment.Adapt<Payment>();
                            payments.Add(payment);
                        }
                        bool processPaymentSuccess = await UpdatePaymentAsync(payments, requestModel.OrderId.Value).ConfigureAwait(false);
                        if (processPaymentSuccess)
                        {
                            List<BulkOrder> bulkUpdateOrders = new List<BulkOrder>();
                            foreach (var bulkOrderRequest in requestModel.BulkRequests)
                            {
                                var bulkOrder = new BulkOrder();
                                bulkOrder = bulkOrderRequest.Adapt<BulkOrder>();
                                bulkOrder.ShippingMethodId = shippingMethods.Where(s => s.TypeCode == bulkOrderRequest.ShippingMethodName).FirstOrDefault().TypeId;
                                bulkOrder.CreatedDate = DateTimeOffset.UtcNow.Date;
                                bulkUpdateOrders.Add(bulkOrder);
                            }
                            var bulkOrdersSuccess = await _orderRepository.UpdateBulkOrderAsync(bulkUpdateOrders).ConfigureAwait(false);
                        }
                    }
                }
                else
                {
                    _logger.LogError($"Could not find the OrderId");
                }
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "UpdateBulkOrdersAsync");
                throw;
            }
        }

        private async Task<int?> ProcessOrderAsync(int? totalBulkOrders)
        {
            var status = await _orderRepository.GetOrderStatusDataAync().ConfigureAwait(false);
            var orderId = await _orderRepository.CreateOrderAsync(new Repository.Models.Order
            {
                CreatedDate = DateTimeOffset.UtcNow.Date,
                OrderStatusId = status.Where(o => o.TypeCode == "New").FirstOrDefault().TypeId,
                OrderConfirmationNumber = Guid.NewGuid().ToString(),
                TotalBulkOrders = totalBulkOrders
            }).ConfigureAwait(false);
            return orderId;
        }

        private async Task<bool> ProcessPaymentAsync(List<Payment> payments, int? orderId)
        {
            bool response = false;
            if (orderId.HasValue && orderId.Value > 0 && payments?.Count > 0)
            {
                var paymentRequestModel = new PaymentRequestModel();
                paymentRequestModel.Payments = payments;
                paymentRequestModel.Payments.ForEach(x => x.OrderId = orderId.Value);
                response = await _paymentSvcProxy.CreateOrderPaymentAsync(paymentRequestModel).ConfigureAwait(false);
            }
            return response;
        }

        private async Task<bool> UpdatePaymentAsync(List<Payment> payments, int? orderId)
        {
            bool response = false;
            if (orderId.HasValue && orderId.Value > 0 && payments?.Count > 0)
            {
                var paymentRequestModel = new PaymentRequestModel();
                paymentRequestModel.Payments = payments;
                paymentRequestModel.Payments.ForEach(x => x.OrderId = orderId.Value);
                response = await _paymentSvcProxy.UpdateOrderPaymentAsync(paymentRequestModel).ConfigureAwait(false);
            }
            return response;
        }
    }
}
