﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Egen.OrderSvc.Config
{
    public class SqlQueries
    {
        public List<QueryMetadata> Queries { get; set; }
    }
    public class QueryMetadata
    {
        public string QueryName { get; set; }
        public string QueryString { get; set; }
        public List<string> Aliases { get; set; }
    }
}
