﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Egen.OrderSvc.Repository.Models
{
    public partial class OrderCustomer : Audit
    {
        public int OrderCustomerId { get; set; }
        public int OrderId { get; set; }
        public int CustomerId { get; set; }
    }
}
