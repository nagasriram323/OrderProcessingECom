﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Egen.OrderSvc.Repository.Models
{
    public partial class Order : Audit
    {
        public int OrderId { get; set; }
        public int OrderStatusId { get; set; }
        public string OrderConfirmationNumber { get; set; }
        public int? TotalBulkOrders { get; set; }
    }
}
