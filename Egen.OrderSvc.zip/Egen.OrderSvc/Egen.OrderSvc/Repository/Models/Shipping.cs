﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Egen.OrderSvc.Repository.Models
{
    public partial class Shipping : Audit
    {
        public int ShippingId { get; set; }
        public int OrderId { get; set; }
        public string AddressLine1 { get; set; }
        public string AddressLine2 { get; set; }
        public string City { get; set; }
        public string State { get; set; }
        public string Zip { get; set; }
        public int ShippingMethodId { get; set; }
        public int CustomerId { get; set; }
    }
}
