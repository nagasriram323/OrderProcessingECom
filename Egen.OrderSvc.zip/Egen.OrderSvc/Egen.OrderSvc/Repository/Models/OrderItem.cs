﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Egen.OrderSvc.Repository.Models
{
    public partial class OrderItem : Audit
    {
        public int OrderItemId { get; set; }
        public int ItemId { get; set; }
        public int ItemQuantity { get; set; }
        public decimal ItemPrice { get; set; }
        public decimal Tax { get; set; }
        public decimal Total { get; set; }
    }
}
