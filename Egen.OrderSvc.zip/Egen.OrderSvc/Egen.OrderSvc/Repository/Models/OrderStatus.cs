﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Egen.OrderSvc.Repository.Models
{
    public partial class OrderStatus : Audit
    {
        public int OrderStatusId { get; set; }
        public string OrderStatusName { get; set; }
        public string OrderStatusDescription { get; set; }
    }
}
