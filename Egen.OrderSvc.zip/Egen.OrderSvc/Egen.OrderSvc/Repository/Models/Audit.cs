﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace Egen.OrderSvc.Repository.Models
{
    public class Audit
    {
        /// <summary>
        /// CreatedDate
        /// </summary>
        [Required]
        public DateTime CreatedDate { get; set; }
        
        /// <summary>
        /// LastUpdatedDate
        /// </summary>
        public DateTime? LastUpdatedDate { get; set; }

        /// <summary>
        /// Version
        /// </summary>
        [Required]
        [Timestamp]
        public byte[] Version { get; set; }
    }
}
