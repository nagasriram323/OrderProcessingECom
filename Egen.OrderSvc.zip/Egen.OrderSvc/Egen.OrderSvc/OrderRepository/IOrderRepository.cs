﻿using Egen.OrderSvc.Models.ResponseModel;
using Egen.OrderSvc.Repository.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Egen.OrderSvc.OrderRepository
{
    public interface IOrderRepository
    {
        Task<int?> CreateOrderAsync(Order order);
        Task<List<DataModel>> GetOrderStatusDataAync();
        Task<List<DataModel>> GetShippingMethodDataAync();
        Task CreateShippingAsync(Shipping shippingModel);
        Task CreateOrderItemAsync(OrderItem orderItem);
        Task CreateOrderCustomerAsync(OrderCustomer orderCustomer);
        Task<OrderDetailsResponseModel> GetOrderDetailsAsync(int orderId);
        Task CancelOrderAsync(int orderId);
        Task<bool> CreateBulkOrderAsync(List<BulkOrder> bulkOrders);
        Task<bool> UpdateBulkOrderAsync(List<BulkOrder> bulkOrders);
        Task<List<BulkOrder>> GetBulkOrdersAsync(int orderId);
    }
}
