﻿using Egen.OrderSvc.Config;
using Egen.OrderSvc.Models.ResponseModel;
using Egen.OrderSvc.Repository;
using Egen.OrderSvc.Repository.Models;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Dapper;
using Microsoft.EntityFrameworkCore;
using System.Data;
using Microsoft.EntityFrameworkCore.Storage;
using EFCore.BulkExtensions;

namespace Egen.OrderSvc.OrderRepository
{
    public class OrderRepository1 : IOrderRepository
    {
        private readonly OrderDbContext _dbContext;
        private readonly SqlQueries _sqlQueries;
        private readonly ILogger<OrderRepository1> _logger;
        private const string GetOrderStatusData = "GetOrderStatus";
        private const string GetShippingMethodData = "GetShippingMethods";
        private const string GetItemData = "GetItems";
        private const string GetOrderDetails = "GetOrderDetails";
        public OrderRepository1(OrderDbContext dbContext,ILogger<OrderRepository1> logger,IOptions<SqlQueries> sqlQueries)
        {
            if (sqlQueries is null)
            {
                throw new ArgumentNullException(nameof(sqlQueries));
            }
            _dbContext = (OrderDbContext)dbContext;
            _logger = logger ?? throw new ArgumentNullException(nameof(logger));
            _sqlQueries = sqlQueries.Value;
        }

        public async Task<int?> CreateOrderAsync(Order order)
        {
            if (order == null)
            {
                throw new ArgumentNullException(nameof(order));
            }
            try
            {
                var orderEntry = await _dbContext.AddAsync(order).ConfigureAwait(false);
                await _dbContext.SaveChangesAsync().ConfigureAwait(false);

                return orderEntry?.Entity.OrderId;
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, $"CreateOrderAsync");
                throw;
            }
        }

        public async Task<List<DataModel>> GetOrderStatusDataAync()
        {
            try
            {
                var connection = (IDbConnection)_dbContext.Database.GetDbConnection();
                var dbtransaction = _dbContext.Database.CurrentTransaction?.GetDbTransaction();
                var queryDesc = _sqlQueries.Queries.First(q => q.QueryName == GetOrderStatusData);
                var result = await connection.QueryAsync<DataModel>(queryDesc.QueryString, null, dbtransaction).ConfigureAwait(false);
                return result.ToList();
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, $"GetOrderStatusReferenceDataAync");
                throw;
            }
        }

        public async Task<List<DataModel>> GetShippingMethodDataAync()
        {
            try
            {
                var connection = (IDbConnection)_dbContext.Database.GetDbConnection();
                var dbtransaction = _dbContext.Database.CurrentTransaction?.GetDbTransaction();
                var queryDesc = _sqlQueries.Queries.First(q => q.QueryName == GetShippingMethodData);
                var result = await connection.QueryAsync<DataModel>(queryDesc.QueryString, null, dbtransaction).ConfigureAwait(false);
                return result.ToList();
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, $"GetShippingMethodReferenceDataAync");
                throw;
            }
        }

        public async Task CreateShippingAsync(Shipping shipping)
        {
            if (shipping == null)
            {
                throw new ArgumentNullException(nameof(shipping));
            }
            try
            {
                await _dbContext.AddAsync(shipping).ConfigureAwait(false);
                await _dbContext.SaveChangesAsync().ConfigureAwait(false);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, $"CreateShippingAsync");
                throw;
            }
        }

        public async Task CreateOrderItemAsync(OrderItem orderItem)
        {
            if (orderItem == null)
            {
                throw new ArgumentNullException(nameof(orderItem));
            }
            try
            {
                await _dbContext.AddAsync(orderItem).ConfigureAwait(false);
                await _dbContext.SaveChangesAsync().ConfigureAwait(false);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, $"CreateOrderItemAsync");
                throw;
            }
        }

        public async Task CreateOrderCustomerAsync(OrderCustomer orderCustomer)
        {
            if (orderCustomer == null)
            {
                throw new ArgumentNullException(nameof(orderCustomer));
            }
            try
            {
                await _dbContext.AddAsync(orderCustomer).ConfigureAwait(false);
                await _dbContext.SaveChangesAsync().ConfigureAwait(false);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, $"CreateOrderCustomerAsync");
                throw;
            }
        }

        public async Task<OrderDetailsResponseModel> GetOrderDetailsAsync(int orderId)
        {
            if (orderId <= 0)
                throw new ArgumentOutOfRangeException($"{nameof(orderId)} should be positive integer.");
            IEnumerable<OrderDetailsResponseModel> result = null;
            try
            {
                var connection = (IDbConnection)_dbContext.Database.GetDbConnection();
                var dbtransaction = _dbContext.Database.CurrentTransaction?.GetDbTransaction();
                DynamicParameters parameters = new DynamicParameters() { RemoveUnused = true };
                parameters.Add("@orderId", orderId, DbType.Int32);
                var queryDesc = _sqlQueries.Queries.First(q => q.QueryName == GetOrderDetails);
                result = await connection.QueryAsync<OrderDetailsResponseModel>(queryDesc.QueryString, parameters, dbtransaction).ConfigureAwait(false);
            }
            catch(Exception ex)
            {
                _logger.LogError(ex, $"GetOrderDetailsAsync");
                throw;
            }
            return result.FirstOrDefault();
        }

        public async Task CancelOrderAsync(int orderId)
        {
            if (orderId <= 0)
                throw new ArgumentOutOfRangeException($"{nameof(orderId)} should be positive integer.");
            try
            {
                var orderToCancel = await _dbContext.Orders.Where(o => o.OrderId == orderId).FirstOrDefaultAsync().ConfigureAwait(false);
                if(orderToCancel != null)
                {
                    var shippingMethods = await GetShippingMethodDataAync().ConfigureAwait(false);
                    if(shippingMethods != null)
                    {
                        var shipMethod = shippingMethods.Where(s => s.TypeCode == "Cancel").FirstOrDefault().TypeId;
                        orderToCancel.OrderStatusId = shipMethod;
                        orderToCancel.LastUpdatedDate = DateTimeOffset.UtcNow.Date;
                        await _dbContext.SaveChangesAsync().ConfigureAwait(false);
                    }
                }
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, $"CancelOrderAsync");
                throw;
            }
        }

        public async Task<bool> CreateBulkOrderAsync(List<BulkOrder> bulkOrders)
        {
            if (bulkOrders == null)
            {
                throw new ArgumentNullException(nameof(bulkOrders));
            }
            bool response = false;
            try
            {
                await _dbContext.BulkInsertAsync(bulkOrders).ConfigureAwait(false);
                await _dbContext.SaveChangesAsync().ConfigureAwait(false);
                response = true;
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, $"CreateBulkOrderAsync");
                throw;
            }
            return response;
        }

        public async Task<bool> UpdateBulkOrderAsync(List<BulkOrder> bulkOrders)
        {
            if (bulkOrders == null)
            {
                throw new ArgumentNullException(nameof(bulkOrders));
            }
            bool response = false;
            try
            {
                await _dbContext.BulkUpdateAsync(bulkOrders).ConfigureAwait(false);
                await _dbContext.SaveChangesAsync().ConfigureAwait(false);
                response = true;
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, $"CreateBulkOrderAsync");
                throw;
            }
            return response;
        }

        public async Task<List<BulkOrder>> GetBulkOrdersAsync(int orderId)
        {
            List<BulkOrder> bulkOrders = null;
            try
            {
                bulkOrders = await _dbContext.BulkOrders.Where(x => x.OrderId == orderId).ToListAsync();
            }
            catch(Exception ex)
            {
                _logger.LogError(ex, $"CreateBulkOrderAsync");
                throw;
            }
            return bulkOrders;
        }
    }
}
